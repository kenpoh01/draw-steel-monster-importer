Draw Steel PDF Monster Importer for Foundryvtt

This is a module for the FoundryVTT to import Draw Steel Monsters from the MCDM Heroes pdf.

The Draw Steel System for Foundry Virtual Tabletop is an independent product published under the DRAW STEEL Creator License and is not affiliated with MCDM Productions, LLC. DRAW STEEL © 2024 MCDM Productions, LLC.

TO INSTALL: Drop the draw-steel-monster-importer folder into your modules folder before launching FoundryVTT. After launching the software, in should appear under the "Add-on modules" tab. Launch your draw-steel world. Then, activate the module under "Game Settings" and "Manage Modules".

When you go to the "Create Actor" tab, there should be an "Import Monster" button at the bottom of the panel. Click it and follow the instructions. Copy and paste the associate blocks from the Heroes pdf.  NOTE: I use foxit reader for my pdf work.  You may have to select multiple text blocks in the pdf as it doesn't seem like you can select the whole thing.
ALSO NOTE: you have to put an * between the header and each ability to help the parser separate things properly.


https://github.com/user-attachments/assets/7880fea8-20a1-4e86-af96-7d5d93cfbe43


